CREATE TABLE IF NOT EXISTS circles (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 name TEXT NOT NULL,
 type TEXT NOT NULL CHECK(type IN ('جماعية','فردية')),
 teacher TEXT,
 telegram_chat_id TEXT,
 meeting_url TEXT,
 days TEXT,
 time TEXT,
 reminder_minutes INTEGER NOT NULL DEFAULT 30,
 created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS students (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 name TEXT NOT NULL,
 number TEXT,
 circle_id INTEGER REFERENCES circles(id) ON DELETE SET NULL,
 teacher TEXT,
 companion TEXT,
 plan TEXT NOT NULL DEFAULT 'حفظ جديد',
 portion TEXT NOT NULL DEFAULT 'نصف وجه',
 new_portion TEXT NOT NULL DEFAULT 'نصف وجه',
 review_portion TEXT NOT NULL DEFAULT 'وجه',
 mastery_portion TEXT NOT NULL DEFAULT 'ربع وجه',
 start_page REAL NOT NULL DEFAULT 1,
 last_page REAL NOT NULL DEFAULT 1,
 last_verse_key TEXT,
 login_username TEXT,
 login_password_hash TEXT,
 login_password_salt TEXT,
 active INTEGER NOT NULL DEFAULT 1,
 fee_exempt INTEGER NOT NULL DEFAULT 0,
 created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS attendance (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 student_id INTEGER NOT NULL REFERENCES students(id) ON DELETE CASCADE,
 date TEXT NOT NULL,
 attendance TEXT NOT NULL,
 completion TEXT,
 recitation TEXT,
 amount TEXT,
 notes TEXT,
 created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS quran_progress (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 student_id INTEGER NOT NULL REFERENCES students(id) ON DELETE CASCADE,
 kind TEXT NOT NULL,
 portion TEXT,
 from_page REAL,
 to_page REAL,
 from_verse_key TEXT,
 to_verse_key TEXT,
 completed INTEGER NOT NULL DEFAULT 0,
 notes TEXT,
 created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS tests (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 student_id INTEGER NOT NULL REFERENCES students(id) ON DELETE CASCADE,
 type TEXT NOT NULL,
 score REAL NOT NULL,
 max_score REAL NOT NULL,
 date TEXT NOT NULL,
 note TEXT,
 created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS ledger (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 student_id INTEGER NOT NULL REFERENCES students(id) ON DELETE CASCADE,
 kind TEXT NOT NULL CHECK(kind IN ('رسوم','دفعة','غرامة','تسوية دائنة')),
 amount REAL NOT NULL CHECK(amount >= 0),
 note TEXT,
 payment_destination TEXT,
 payment_method TEXT,
 transaction_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
 created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS meetings (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 circle_id INTEGER NOT NULL REFERENCES circles(id) ON DELETE CASCADE,
 starts_at TEXT NOT NULL,
 reminder_sent INTEGER NOT NULL DEFAULT 0,
 created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE UNIQUE INDEX IF NOT EXISTS idx_students_login_username ON students(login_username) WHERE login_username IS NOT NULL;
CREATE INDEX IF NOT EXISTS idx_students_circle ON students(circle_id);
CREATE INDEX IF NOT EXISTS idx_attendance_student_date ON attendance(student_id,date);
CREATE INDEX IF NOT EXISTS idx_quran_student_date ON quran_progress(student_id,created_at);
CREATE INDEX IF NOT EXISTS idx_tests_student_date ON tests(student_id,date);
CREATE INDEX IF NOT EXISTS idx_ledger_student_date ON ledger(student_id,created_at);
CREATE INDEX IF NOT EXISTS idx_meetings_start ON meetings(starts_at,reminder_sent);

CREATE TABLE IF NOT EXISTS app_settings (
 key TEXT PRIMARY KEY,
 value TEXT NOT NULL,
 updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
