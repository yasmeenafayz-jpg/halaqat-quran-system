ALTER TABLE students ADD COLUMN login_username TEXT;
ALTER TABLE students ADD COLUMN login_password_hash TEXT;
ALTER TABLE students ADD COLUMN active INTEGER NOT NULL DEFAULT 1;
ALTER TABLE students ADD COLUMN fee_exempt INTEGER NOT NULL DEFAULT 0;
CREATE UNIQUE INDEX IF NOT EXISTS idx_students_login_username ON students(login_username) WHERE login_username IS NOT NULL;
ALTER TABLE students ADD COLUMN login_password_salt TEXT;
