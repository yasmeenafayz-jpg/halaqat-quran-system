ALTER TABLE ledger ADD COLUMN payment_destination TEXT;
ALTER TABLE ledger ADD COLUMN payment_method TEXT;
ALTER TABLE ledger ADD COLUMN transaction_at TEXT;
UPDATE ledger SET transaction_at = COALESCE(transaction_at, created_at);
CREATE TABLE IF NOT EXISTS app_settings (
 key TEXT PRIMARY KEY,
 value TEXT NOT NULL,
 updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
INSERT OR IGNORE INTO app_settings(key,value) VALUES ('payment_number','');
INSERT OR IGNORE INTO app_settings(key,value) VALUES ('payment_label','رقم التحويل المالي');
